const { supabase } = require('../config/supabaseClient');
require('dotenv').config();


// Upload base64 image to Supabase
const uploadToSupabase = async (base64Data, folder, fileName) => {
    const base64 = base64Data.split(';base64,').pop(); // remove header
    const buffer = Buffer.from(base64, 'base64');

    const fullPath = `${folder}/${Date.now()}-${fileName}`;

    const { error: uploadError } = await supabase
        .storage
        .from('farmer-docs')
        .upload(fullPath, buffer, {
            contentType: 'image/jpeg', // you can make this dynamic if needed
        });

    if (uploadError) {
        throw new Error(`Upload failed: ${uploadError.message}`);
    }

    const { data } = supabase
        .storage
        .from('farmer-docs')
        .getPublicUrl(fullPath);

    return data.publicUrl;
};

const generateFarmerId = () => {
    const randomNum = Math.floor(Math.random() * 900) + 100; // Generates a random 3-digit number (100-999)
    return `farm${randomNum}`;
};

exports.registerFarmer = async (req, res) => {
    try {
        const { name, mobile, aadharCard, landRecord, profilePic, rationCard } = req.body;

        if (!name || !mobile || !aadharCard || !landRecord || !profilePic || !rationCard) {
            return res.status(400).json({ message: 'All fields and documents are required' });
        }

        const farmerId = generateFarmerId();

        const aadharUrl = await uploadToSupabase(aadharCard, `aadhar/${farmerId}`, 'aadhar.jpg');
        const landRecordUrl = await uploadToSupabase(landRecord, `land/${farmerId}`, 'land.jpg');
        const profilePicUrl = await uploadToSupabase(profilePic, `profile/${farmerId}`, 'profile.jpg');
        const rationCardUrl = await uploadToSupabase(rationCard, `ration/${farmerId}`, 'ration.jpg');

        // Insert into Supabase
        const { error } = await supabase
            .from('farmer')
            .insert([{
                name,
                mobile_number: mobile,
                farmer_id: farmerId,
                aadhar_image_url: aadharUrl,
                land_record_url: landRecordUrl,
                profile_picture_url: profilePicUrl,
                ration_card_url: rationCardUrl,
                status: 'pending',
                created_at: new Date(),
            }]);


        if (error) {
            console.error('Supabase error:', error);
            return res.status(500).json({ message: 'Database insert failed' });
        }

        res.status(200).json({ message: 'Registration successful. Waiting for approval.' });
    } catch (err) {
        console.error('Registration error:', err);
        res.status(500).json({ message: 'Server error' });
    }
};

// GET /api/farmers/pending
exports.getPendingFarmers = async (req, res) => {
    try {
        const { data, error } = await supabase
            .from('farmer')
            .select('*')
            .eq('status', 'pending');

        if (error) {
            console.error('Supabase fetch error:', error);
            return res.status(500).json({ message: 'Failed to fetch farmers' });
        }

        res.status(200).json(data);
    } catch (err) {
        console.error('Server error:', err);
        res.status(500).json({ message: 'Server error' });
    }
};

// PUT /api/farmers/approve/:id
exports.approveFarmer = async (req, res) => {
    const farmerId = req.params.id;
    const { data, error } = await supabase
        .from('farmer')
        .update({ status: 'approved' })
        .eq('farmer_id', farmerId);

    if (error) {
        return res.status(500).json({ message: 'Approval failed' });
    }
    res.status(200).json({ message: 'Farmer approved successfully' });
};

const express = require('express');
const router = express.Router();
const farmerController = require('../controllers/farmerController');

router.post('/register', farmerController.registerFarmer);
router.put('/approve/:id', farmerController.approveFarmer);
router.get('/pending', farmerController.getPendingFarmers);


module.exports = router;
